<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * only these is for registering a new student form the first page
 */
class Register extends CI_Model
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
	}
	public function registerNew($data)//register username and password
	{
		//get the number of candidates in the database of the same date to assign a reference number
    $yearOnly=substr($data['year_registered'],0,4);
    $gets=$this->db->query("SELECT year_registered FROM candidates");
    $results=$gets->result();
    $value=0;
    foreach ($results as $values) {
      if (substr($values->year_registered,0,4)==$yearOnly) {
        $value++;
      }
    }
    $reference=$yearOnly.$value;
    // query to save data in the database
    $data['reference_no']=$reference;
     $this->db->insert('candidates',$data);
     if ($this->db->affected_rows()>0) {
       //make a candidate an applicant
       $this->load->view('views_pages/account.php');//redirect to login
     } else {
       $this->load->view('views_pages/registerFormMain.php');
     }
	}
	//submit/save application
	public function saveApplication($data)
	{
		// check if an applicant of the details as current user has submitted application
		$ref=$data['reference_no'];
		$condition=array(
	    'reference_no'=>$data['reference_no'],
	  );
		$values=$this->db->get_where('applications',$condition);
	  $elements=$values->result_array();
		if (count($elements)>0) {
			// run update
			//get the current number of applications submitted
			foreach ($values->result() as $row) {
	      $number=$row->number_of_application;
	    }
			$data['number_of_application']=$number+1;
			$this->db->where('reference_no',$ref);
		  $this->db->update('applications',$data);
			//redirect
			$prog=$data['program_id'];
			$this->redirectUser($prog);
		}else {
			//insert application
			$this->db->insert('applications',$data);
			//redirect
			$prog=$data['program_id'];
			$this->redirectUser($prog);
		}
	}
	//only to redirect
	public function redirectUser($program) //redirect back to review page
	{
		switch ($program) {
			case '01':
				$this->load->view('certificate/review_application.php');
				break;
			case '02':
				$this->load->view('certificate/review_application.php');
				break;
			case '03':
					$this->load->view('bachelor_master/review_application.php');
					break;
			case '04':
					$this->load->view('bachelor_master/review_application.php');
					break;
			default:
				$this->load->view('views_pages/home.php');
				break;
		}
	}
	//check if application has been submitted
	public function checkApplications($condition)
	{
		//retrieve application
		$values=$this->db->get_where('applications',$condition);
	  $elements=$values->result_array();
		if (count($elements)>0) {
			return TRUE;
		}else {
			return FALSE;
		}
	}//end of the function
	public function addUsertype($data)
	{
		// add new system user responsability in database
		$this->db->insert('users_responsabilities',$data);
		//$sql=$this->db->query("INSERT INTO users_responsabilities(responsability) VALUES('$cond') WHERE responsability NOT IN '$cond'");
		if ($this->db->affected_rows()>0) {
			return true;
		}else {
			return false;
		}
	}//end of the function
	public function addUserdata($data)
	{
		// add new system user responsability in database
		$this->db->insert('users',$data);
		if ($this->db->affected_rows()>0) {
			return true;
		}else {
			return false;
		}
	}//end of function
	public function savefile($files)
	{
		//save file
		$this->db->insert('files',$files);
		if ($this->db->affected_rows()>0) {
			return true;
		}else {
			return false;
		}
	}//end of function
	public function changeStatus($data)
	{
		$this->db->where('email',$data['email']);
		$this->db->update('users',array('status'=>$data['status']));
		if ($this->db->affected_rows()>0) {
			return true;
		}else {
			return false;
		}
	}//end of function
}
 ?>
