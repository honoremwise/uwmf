<?php
/**
 * This model is for working with all data access(selection) from database
 */
class SelectModels extends CI_Model
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
	}
	public function retrieveprogram()
  {
    $user=$this->session->userdata('username');
    $pass=$this->session->userdata('password');
    $value=$this->db->query("SELECT program_id FROM candidates WHERE candidate_email LIKE '$user'");
    foreach ($value->result() as $row) {
      return $row->program_id;
    }
  }//end of functio definition
	public function checkLogin($user,$pass){
		//check that a user id and username exist in database
		$this->db->select('candidate_email','password','program_id');
		$this->db->from('candidates');
		$this->db->where('candidate_email',$user);
		$this->db->where('password',$pass);
		$this->db->limit(1);
		$query=$this->db->get();
		if ($query->num_rows()==1) {
			$sql=$this->db->query("SELECT program_id,candidate_email,password FROM candidates WHERE candidate_email LIKE '$user'");
			foreach ($sql->result() as $row) {
				$programID=$row->program_id;//
				$validuser=$row->candidate_email;
				$validpass=$row->password;
				if ($validuser==$user && $validpass==$pass) {
					return $programID;
				}else {
					return false;
				}
			}
		} else {
			return false;
		}
	}//end of function definition
	public function saveData($user)
	{
		//select a record from the database to check a valid login
		$query=$this->db->query("SELECT first_name,last_name,program_id FROM candidates WHERE candidate_email LIKE '$user'");
		foreach($query->result() as $row) {
			$first=$row->first_name;
			$last=$row->last_name;
			$program=$row->program_id;
			if ($first!="" && $last!="" && $program!="") {
				return $program;
			}else {
				return FALSE;
			}
		}
	}//end of function definition
	public function savework($user)
	{
		$query=$this->db->query("SELECT denomination,	church_name,church_phone FROM church_information WHERE reference_no LIKE '$user'");
		$values=$query->result_array();
		if (count($values)>0) {
			$query=$this->db->query("SELECT program_id FROM candidates WHERE reference_no LIKE '$user'");
			foreach($query->result() as $row){
				return $row->program_id;
			}
		}else {
			return FALSE;
		}
	}//end of function definition
	public function checkexperience($user)
	{
		$query=$this->db->query("SELECT realwork_cmp,realwork_start FROM church_information WHERE reference_no LIKE '$user'");
		$values=$query->result_array();
		if (count($values)>0){
			foreach ($query->result() as $value) {
				$work=$value->realwork_cmp;
				$date=$value->realwork_start;
			}
			if ($work!="" && $date!="") {
				$query=$this->db->query("SELECT program_id FROM candidates WHERE reference_no LIKE '$user'");
				foreach($query->result() as $row){
					return $row->program_id;
				}
			}else {
				return FALSE;
			}
		}else {
			return FALSE;
		}
	}
	//function to retrieve all emails to check uniqueness while creating account
	public function checkuseremail($condition)
	{
		$resultset=$this->db->get_where("candidates",$condition);
		$elements=$resultset->result_array();
		if (count($elements) >0) {
			return false;
		} else {
			return true;
		}
	}//end of function
	//check if a user is a student
	public function checkstudent($condition)
	{
		$resultset=$this->db->get_where("students",$condition);
		$elements=$resultset->result_array();
		if (count($elements) >0) {
			return true;
		} else {
			return false;
		}
	}//end of function
	public function checkuser($user,$pass)
	{
		$condition=array('username'=>$user,
		'password'=>$pass,
	);
	$resultset=$this->db->get_where("users",$condition);
	$elements=$resultset->result_array();
	if (count($elements) >0) {
		return true;
	} else {
		return false;
	}
}//end of function
	public function getusers()
	{
		return $this->db->query("SELECT * FROM users WHERE responsability!='admin'")->result();
	}//end of function
	public function getpositions($value='')
	{
		return $this->db->query("SELECT * FROM users_responsabilities")->result();
	}//end of function
	public function getfiles()
	{
		return $this->db->query("SELECT * FROM files")->result();
	}
}
?>
