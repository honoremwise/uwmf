<?php
/**
 *only this model is for user to register existing students who did not applied using system
 */
class tempModels extends CI_Model
{

  function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
	}
	public function retrieveprogram()
  {
    $user=$this->session->userdata('username');
    $pass=$this->session->userdata('password');
    $value=$this->db->query("SELECT program_id FROM candidates WHERE candidate_email LIKE '$user'");
    foreach ($value->result() as $row) {
      return $row->program_id;
    }
  }//end of functio definition
	public function checkLogin($user,$pass){
		//check that a user id and username exist in database
    $condition=array(
      'email'=>$user,
      'password'=>$pass,
    );
    $data=$this->db->get_where('users',$condition);
    $elements=$data->result_array();
    if (count($elements)) {
      foreach ($data->result() as $row) {
        $emailid=$row->email;
        $passportid=$row->password;
        if ($emailid==$user && $passportid==$pass) {
          return TRUE;
        }
      }
    }else {
      return FALSE;
    }
	}//end of function definition
  public function registerNew($first,$last,$email,$programcode,$year)//register username and password
	{
		// query to save data in the database
		 $sql="insert into candidates(first_name,last_name,candidate_email,program_id,year_registered)values('$first','$last','$email','$programcode',$year)";
		 if (null !==$this->db->error()) {
		 	$this->db->query($sql);
			//give this applicant a reference number
			$cond=array('year_registered'=>$year,);
			$values=$this->db->get_where('candidates',$cond);
		  $elements=$values->result_array();
			$count=count($elements);
			if ($count >= 0) {
				$sql=$this->db->query("SELECT candidate_id FROM candidates WHERE candidate_email LIKE '$email'");
				foreach ($sql->result() as $row) {
					$value= $year.$count;
					$data=array(
						'reference_no'=>$value,
					);
					$this->db->where('candidate_email',$email);
			    $this->db->update('candidates',$data); //give a candidate a reference number
          //make an a candidate a real applicant
          //get a candidate reference number
          $cond=array('candidate_email'=>$email,);
          $values=$this->db->get_where('candidates',$cond);
          $elements=$values->result_array();
          if (count($elements)>0) {
            foreach ($values->result() as $row) {
              $reference=$row->reference_no;
              $program=$row->program_id;
              return array($reference,$program);
            }
          }
				}
			}else {
        $data=array('erroruser'=>'An error occured, Please try again');
        $this->load->view('tempuser/index.php');
      }
		 } else {
       $data=array('erroruser'=>'An error occured, please try again');
		 	$this->load->view('tempuser/index.php');
		 }
	}//end of function definition
  public function saveApplication($data)
	{
		// check if an applicant of the details as current user has submitted application
		$ref=$data['reference_no'];
		$condition=array(
	    'reference_no'=>$data['reference_no'],
	  );
		$values=$this->db->get_where('applications',$condition);
	  $elements=$values->result_array();
		if (count($elements)>0) {
			// run update
			//get the current number of applications submitted
			foreach ($values->result() as $row) {
	      $number=$row->number_of_application;
	    }
			$data['number_of_application']=$number;
			$this->db->where('reference_no',$ref);
		  $this->db->update('applications',$data);
			$prog=$data['program_id'];
      return $prog;
		}else {
			//insert application
			$this->db->insert('applications',$data);
			//redirect
			$prog=$data['program_id'];
			return $prog; //its time to save personal data
		}
	}//end of function
  public function registerBasicData($data)
	{
		    //update data in database where username and password match
		    //retrieve user and password form session variable
		    //update command
        $user=$data['candidate_email'];
		    $this->db->where('candidate_email',$user);
		    $this->db->update('candidates',$data);
        if ($this->db->affected_rows()>0) {
          //If the query runs well make an applicant a student
          //select branch_id, program_id,year_registered,reference_no
          $values=$this->db->get_where('candidates',array('candidate_email'=>$user));
          $elements=$values->result_array();
          if (count($elements)>0) {
            foreach ($values->result() as $row) {
              $reference=$row->reference_no;
              $program=$row->program_id;
              $branch=$row->branch_code;
              $year=$row->year_registered;
              if (!empty($program)) {
                return array($reference,$program,$branch,$year);
              }else {
                return FALSE;
              }
            }
          }else {
            return false;
          }
        }else {//error of update
          return false;
        }
	}//end of class definition
  public function getbranchcode($id){
    $value=$this->db->query("SELECT branch_code FROM branches WHERE branch_id LIKE '$id'");
    foreach ($value->result() as $row) {
      return $row->branch_code;
    }
  }//end of the function
  public function saveStudent($data)
  {
    //check if student of the same index exist
    $values=$this->db->get_where('students',array('registration_no'=>$value['registration_no']));
	  $elements=$values->result_array();
		if (count($elements)>0) {
      return false;
    }else {//run insert
      $this->db->insert('students',$data);
      if ($this->db->affected_rows()>0) {
        return true;
      }else {//error of saving student
        return false;
      }
    }
  }//end of function definition
  public function savePassword($password,$reference)
  {
    // update table based on reference
    $this->db->where('reference_no',$reference);
    $this->db->update("candidates",array('password'=>$password));
    if ($this->db->affected_rows()>0) {
      return true;
    }else {
      return false;
    }
  }
  public function retrieveReference($data)
  {
    $values=$this->db->get_where('students',$data);
    $elements=$values->result_array();
    if (count($elements)>0) {
      foreach ($values->result() as $row) {
        $reference=$row->reference_no;
        return $reference;
      }
    }else {
      return false;
    }
  }//end of the function
  public function work_experience($data)
	{
		//register church information and candidate experience(certificate && diploma)
		//retrieve reference number for this id
		$ref=$data['reference_no'];
		$reference=$this->db->query("SELECT reference_no FROM church_information WHERE reference_no LIKE '$ref'");
		$elements=$reference->result_array();
		if (count($elements)>0) {
			unset($data['reference_no']);
      unset($data['studentnumber']);
			$this->db->where('reference_no',$ref);
		  $this->db->update('church_information',$data);
			//redirect to the next page (inex)
      if ($this->db->affected_rows()>0) {
        return true;
      }else {
        return false;
      }
		}else {
			//run insert instead of updating
      unset($data['studentnumber']);
			$this->db->insert('church_information',$data);
			//redirect to the next page(index)
			if ($this->db->affected_rows()>0) {
        return true;
      }else {
        return false;
      }
		}
	}//end of the function
  public function job_experience($data)
	{
		$ref=$data['reference_no'];
		unset($data['reference_no']);
		$this->db->where('reference_no',$ref);
		$this->db->update('church_information',$data);
		if ($this->db->affected_rows()>0) {
      return true;
    }else {
      return false;
    }
	}//end of the function
  public function cert_files_upload($file,$field,$reference)
  {
    $data=array(
    $field=>$file,
    );
    //update command
    $this->db->where('reference_no',$reference);
    $this->db->update('candidates',$data);
    //get the program code to know which page to load
    if ($this->db->affected_rows()>0) {
      return true;
    }else {
      return false;
    }
  }//end of the function
  public function getuser($value)
  {
    $values=$this->db->get_where('students',array('registration_no'=>$value));
    $elements=$values->result_array();
    if (count($elements)>0) {
      foreach ($values->result() as $row) {
        $ref=$row->reference_no;
        //retrieve email address
        $value=$this->db->query("SELECT candidate_email FROM candidates WHERE reference_no like '$ref'");
        $elements=$value->result_array();
        if (count($elements)>0) {
          foreach ($value->result() as $get) {
            return $get->candidate_email;
          }
        }else {
          return false;
        }
      }
    }else {
      return false;
    }
  }//end of function
  public function updateData($data)
  {
    $cond=$data['reference_no'];
    unset($data['reference_no']);
    $this->db->where('reference_no',$cond);
    $this->db->update('candidates',$data);
    if ($this->db->affected_rows()>0) {
      return true;
    }else {
      return false;
    }
  }//end of function
  public function updatechurch($data)
  {
    $cond=$data['reference_no'];
    unset($data['reference_no']);
    $this->db->where('reference_no',$cond);
    $this->db->update('church_information',$data);
    if ($this->db->affected_rows()>0) {
      return true;
    }else {
      return false;
    }
  }//end of the function
  public function updatenumber($regno,$newregno)
  {
    //check that a user id and username exist in database
    $condition=array(
      'registration_no'=>$regno,
    );
    $data=$this->db->get_where('students',$condition);
    $elements=$data->result_array();
    if (count($elements)>0) {
      // user exist, update query
      $data=array('registration_no'=>$newregno);
      $this->db->where('registration_no',$regno);
      $this->db->update('students',$data);
      if ($this->db->affected_rows()>0) {
        return true;
      }else {
        return false;
      }
    }else {
      return false;
    }
  }//end of function
  public function checkuser($data)
  {
    $values=$this->db->get_where('students',array('registration_no'=>$data['registration_no']));
    $elements=$values->result_array();
    if (count($elements)>0) {
      $user=$_SESSION['validuser'];
      $marks=$data['points'];
      $date=$data['date'];
      //get user id and marks grade
      $gradeUser=$this->db->query("SELECT users.user_id, grades.grade,grades.establishement_date FROM users,grades WHERE users.email='$user' AND grades.lowerbound<='$marks' AND grades.upperbound >='$marks' AND grades.establishement_date<='$date'")->result();
      if (count($gradeUser)>0) {
        foreach ($gradeUser as $row) {
          return(array($row->user_id,$row->grade));//add marks
        }
      }else {
        return false;
      }
    }else {
      return false;
    }
  }//end of function
  public function addMarks($values)
  {
    //check if marks already recorded
    $check=$this->db->get_where('marks',array('registration_no'=>$values['registration_no'],'module_id'=>$values['module_id']));
    $el=$check->result_array();
    if (count($el)>0){
      return false;
    }else {
      //run insert
      $sql=$this->db->insert('marks',$values);
      if ($this->db->affected_rows()>0) {
        return true;
      }else {
        return false;
      }
    }
  }
}//end of class definition
?>
