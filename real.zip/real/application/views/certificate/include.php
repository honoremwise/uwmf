<script type="text/javascript" src="<?php  echo base_url() ?>css_scripts/vendor/jquery/jquery.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url() ?>css_scripts/vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url() ?>css_scripts/vendor/metisMenu/metisMenu.min.js"></script>
<script  src="<?php  echo base_url() ?>css_scripts/js/forms.js"></script>
<!-- Morris Charts JavaScript -->
<script src="<?php echo base_url() ?>css_scripts/vendor/raphael/raphael.min.js"></script>
<script src="<?php echo base_url() ?>css_scripts/vendor/morrisjs/morris.min.js"></script>
<script src="<?php echo base_url() ?>css_scripts/vendor/morrisjs/morris.js"></script>
<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url() ?>css_scripts/dist/js/sb-admin-2.js"></script>
<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url() ?>css_scripts/dist/js/sb-admin-2-min.js"></script>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url() ?>css_scripts/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url() ?>css_scripts/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url() ?>css_scripts/dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo base_url() ?>css_scripts/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
