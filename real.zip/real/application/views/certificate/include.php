<script type="text/javascript" src="<?php  echo base_url() ?>css_scripts/vendor/jquery/jquery.js"></script>
<script src="<?php echo base_url() ?>css_scripts/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url() ?>css_scripts/vendor/metisMenu/metisMenu.min.js"></script>
<script  src="<?php  echo base_url() ?>css_scripts/js/forms.js"></script>
<script src="<?php echo base_url() ?>css_scripts/vendor/raphael/raphael.min.js"></script>
<script src="<?php echo base_url() ?>css_scripts/vendor/morrisjs/morris.min.js"></script>
<script src="<?php echo base_url() ?>css_scripts/vendor/morrisjs/morris.js"></script>
<link href="<?php echo base_url() ?>css_scripts/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url() ?>css_scripts/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">
<link href="<?php echo base_url() ?>css_scripts/dist/css/sb-admin-2.css" rel="stylesheet">
<link href="<?php echo base_url() ?>css_scripts/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
