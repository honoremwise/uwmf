<div>
      <?php echo validation_errors('<div class="alert alert-danger" style="height:1px;">','</div>');?>
			<div>
					<div style="color:red; padding-bottom:10px;">
						<?php
						if (isset($error_file_upload)) {
							echo $error_file_upload;
						}
						?>
					</div>
					<div class="row">
						<div class="col-xs-10 col-sm-10 col-md-6 col-lg-6">
							<form action="<?php echo base_url();?>index.php/Files/saveid"  method="post" enctype="multipart/form-data">
								<div class="form-group">
									<label for="candidateIDnumber">Identity/Passport</label>
									<input type="file" name="identity" class="form-control">
								</div>
								<input type="submit" class="btn  btn-primary btn-sm" value="Upload file">
								<span>
									<?php if (!empty($idcard)) {
										?>
										<a href="<?php echo base_url().'profiles/'.$idcard; ?>" target="_blank">Preview file</a>
										<?php
									} ?>
									</span>
							</form>
						</div>
						<div class="col-xs-10 col-sm-10 col-md-6 col-lg-6">
							<form action="<?php echo base_url();?>index.php/Files/savepicture" method="post" enctype="multipart/form-data">
              <div class="form-group">
								<label for="profile ">Profile Picture</label>
								<input type="file" name="picture" class="form-control">
							</div>
							<input type="submit" class="btn  btn-primary btn-sm" value="Upload file">
							<span>
								<?php if (!empty($photo)) {
								 ?><a href="#">Profile picture uploaded</a>
								 <?php
								} ?>
							</span>
							</form>
						</div>
					</div>

					<div class="row" style="margin-top:20px;">
						<div class="col-xs-10 col-sm-10 col-md-6 col-lg-6">
							<form action="<?php echo base_url();?>index.php/Files/saveid"  method="post" enctype="multipart/form-data">
               <div class="form-group">
								 <label for="candidateDiploma">Certificate</label>
								 <span style="border-left:ridge;">Upload General advanced certificate,diploma or Bachelor degree</span>
								 <input type="file" name="candidatediploma" class="form-control">
							 </div>
							 <input type="submit" class="btn  btn-primary btn-sm" value="Upload file">
							 <span>
								 <?php if (!empty($degree)) {
								 	?><a href="<?php echo base_url().'profiles/'.$degree; ?>"target="_blank">Preview file</a>
									<?php
								 } ?>
							 </span>
							</form>
						</div>
						<div class="col-xs-10 col-sm-10 col-md-6 col-lg-6">
							<form action="<?php echo base_url();?>index.php/Files/saveid" method="post" enctype="multipart/form-data">
								<div class="form-group">
									<label for="candidateBirth">Recommendation</label>
									<span style="border-left:ridge;">Recommendation must be from the Pastor of your Church</span>
									<input type="file" name="candidateRecomm" class="form-control">
								</div>
								<input type="submit" class="btn  btn-primary btn-sm" value="Upload file">
								<span>
									<?php
									if (!empty($recommend)) {
										?>
										<a href="<?php echo base_url().'profiles/'.$recommend; ?>" target="_blank">Preview file</a>
										<?php
									}
									 ?>
								</span>
							</form>
						</div>
					</div>
					<div class="row">
						<div class="col-xs-10 col-sm-10 col-md-6 col-lg-6">
							<form class="" action="<?php echo base_url();?>index.php/Files/saveid" method="post" enctype="multipart/form-data">
								<div class="form-group">
									<label for="transcriptupload">Academic transcripts or reports</label><span style="border-left:ridge;">Upload all transcripts or reports within a single file if you have different copies.</span>
									<input type="file" name="candidatereport" class="form-control">
								</div>
								<input type="submit" class="btn  btn-primary btn-sm" value="Upload file">
								<span>
									<?php
									if (!empty($transcript)) {
										?>
										<a href="<?php echo base_url().'profiles/'.$transcript; ?>" target="_blank">Preview file</a>
										<?php
									}
									 ?>
								</span>
							</form>
						</div>
						<div class="col-xs-10 col-sm-10 col-md-6 col-lg-6">
							<form class="" action="<?php echo base_url();?>index.php/Files/saveid" method="post" enctype="multipart/form-data">
								<div class="form-group">
									<label for="statement of faith">Statement of faith</label>
									</span>
									<input type="file" name="candidatestatement" class="form-control">
								</div>
								<input type="submit" class="btn  btn-primary btn-sm" value="Upload file">
								<span>
									<?php
									if (!empty($statement)) {
										?>
										<a href="<?php echo base_url().'profiles/'.$statement; ?>" target="_blank">Preview file</a>
										<?php
									}
									 ?>
								</span>
							</form>
						</div>
					</div>
          <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
							<form action="<?php echo base_url();?>index.php/Files/saveid"  method="post" enctype="multipart/form-data">
								<div class="form-group">
									<label for="candidatemotivation">Autobiographical Essay</label>
									<input type="file" name="candidatemotivation" class="form-control">
								</div>
								<input type="submit" class="btn  btn-primary btn-sm" value="Upload file">
								<span>
									<?php if (!empty($motiv)) {
									 ?><a href="<?php echo base_url().'profiles/'.$motiv; ?>" target="_blank">Preview file</a>
									 <?php
									} ?>
								</span>
							</form>
						</div>
            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
							<form action="<?php echo base_url();?>index.php/Files/saveid"  method="post" enctype="multipart/form-data">
								<div class="form-group">
									<label for="candidateBirth">Birth Certificate</label>
									<input type="file" name="candidateBirth" class="form-control">
								</div>
								<input type="submit" class="btn  btn-primary btn-sm" value="Upload file">
								<span>
									<?php if (!empty($bd) && $bd!='N/A') {
									 ?><a href="<?php echo base_url().'profiles/'.$bd; ?>" target="_blank">Preview file</a>
									 <?php
									} ?>
								</span>
							</form>
						</div>
          </div>
					<div class="modal fade" tabindex="-1" aria-labelledby="adduser" role="modal" aria-hidden="true" id="addfile">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" name="button" class="close" data-dismiss="modal">&times;</button>
									<h4 class="modal-title">Downloads</h4>
								</div>
								<div class="modal-body">
									<table class="table table-condensed">
										<thead>
										</thead>
										<tbody>
											<tr>
												<td>Statement of faith</td>
												<td>
													<?php if (!empty($faith)) {
														?>
														<a href="<?php echo base_url().'files/'.$faith; ?>" target="_blank">View</a><?php
													} ?>
												</td>
											</tr>
											<tr>
												<td>Recommendation letter format</td>
												<td>
													<?php if (!empty($recommend)) {
														?>
														<a href="<?php echo base_url().'files/'.$recommend; ?>" target="_blank">View</a><?php
													} ?>
												</td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div><!-- end of modal-->
				</div>
			</div>
