<?php
if (isset($_SESSION['username']) && isset($_SESSION['registration'])) {
  require_once(APPPATH.'views/tempuser/datareview.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>UWMF MIS-student-login</title>
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url() ?>css_scripts/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url() ?>css_scripts/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="<?php echo base_url() ?>css_scripts/vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php echo base_url() ?>css_scripts/vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url() ?>css_scripts/dist/css/sb-admin-2.css" rel="stylesheet">
    <script type="text/javascript" src="<?php  echo base_url() ?>css_scripts/vendor/jquery/jquery.js"></script>
    <script type="text/javascript" src="<?php  echo base_url() ?>css_scripts/js/custom.js"></script>
    <!-- Custom Fonts -->
    <link href="<?php echo base_url() ?>css_scripts/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <script type="text/javascript">
      function getout() {
        document.getElementById('addstyle').style.visibility="hidden";
        document.getElementById('recordshow').style.visibility="hidden";
      }
      function showresults() {
        document.getElementById('addmarksbutton').style.visibility="hidden";
      }
    </script>
</head>
<body>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
          <img class="navbar-brand" src="<?php echo base_url();?>css_scripts/vendor/datatables/images/test.png" alt="logo" class="img img-circle">
            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li>
                  <?php
                  if (isset($_SESSION['username'])){
                    ?>
                    <button id="addmarksbutton" type="button" class="btn btn-info" data-toggle="modal" data-target="#myMarks" onclick="showresults()">View Marks</button>
                    <button id="addstyle" type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal" onclick="getout()">View More</button>
                    <?php
                  }
                    ?>
                  </li>
                <li class="sidebar-search">
                      <div class="custom-search-form">
                        <form class="form-inline" action="<?php echo base_url();?>index.php/tempLoad/review" method="post">
                          <div class="form-group">
                            <input type="text" class="form-control" placeholder="Search student..." name="searchitem" id="searchitem">
                          </div>
                          <button class="btn btn-default" type="submit">
                              <i class="fa fa-search"></i>
                          </button>
                        </form>
                      </div>
                  </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li class="divider"></li>
                        <li><a href="<?php echo base_url();?>index.php/tempLoad/Logout"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="#">Add Student<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                  <a href="#application-details" data-toggle="modal" data-target="#application-details">Create Account</a>
                                </li>
                                <li>
                                    <a href="#addnewstudent" data-toggle="modal" data-target="#addnewstudent">Personal Data</a>
                                </li>
                                <li>
                                    <a href="#working_experience" data-toggle="modal" data-target="#working_experience">Church Information</a>
                                </li>
                                <li>
                                  <a href="#job-experience" data-toggle="modal" data-target="#job-experience">Work Experience</a>
                                </li>
                                <li>
                                    <a href="#file-uploads" data-toggle="modal" data-target="#file-uploads">Uploads</a>
                                </li>
                                <li>
                                  <a href="#">Confirm Student</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                          <a href="#">Manage Student<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                  <a href="#bannerformmodal" data-toggle="modal" data-target="#bannerformmodal">Edit student number</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                          <a href="#">Manage Marks<span class="fa arrow"></span></a>
                          <ul class="nav nav-second-level">
                              <li>
                                <a href="#addmarks" data-toggle="modal" data-target="#addmarks">Add student marks</a>
                              </li>
                              <li>
                                <a href="#editmarks" data-toggle="modal" data-target="#editmarks">Edit Marks</a>
                              </li>
                          </ul>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
        <div id="page-wrapper">
          <div class="" id="recordshow">
            <?php
            if (isset($_SESSION['username']) && isset($fname)) {
              require_once(APPPATH.'views/views_pages/default.php');
            }
             ?>
          </div>
          <div class="row" style="color:red;">
    				<?php if (isset($erroruser)) {
    					echo $erroruser;
              unset($erroruser);
    				}
            if (isset($recorderror)) {
              echo $recorderror;
              unset($recorderror);
            }
            if (isset($success)) {
              ?>
              <div class="alert alert-success" style="height:1px;" class="col-lg-4">
                <?php echo $success;
                 ?>
              </div>
              <?php
            }
            ?>
    			</div>
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"></h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="tab-content">
              <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="bannerformmodal" aria-hidden="true" id="bannerformmodal">
                <div class="modal-dialog">
                  <!-- Modal content-->
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 class="modal-title">Edit student number</h4>
                    </div>
                    <div class="modal-body">
                      <form class="" action="<?php echo base_url();?>index.php/tempLoad/getreference" method="post">
                        <div class="form-group">
                          <label for="student number">Student number</label>
                          <input type="text" name="candidatenumberid" value="" id="candidatenumberid" class="form-control" required>
                        </div>
                        <div class="form-group">
                          <label for="newnumber">New student number</label>
                          <input type="text" name="studentnumberid" id="studentnumberid" class="form-control" required>
                        </div>
                        <input type="submit" name="getnumberid" value="Edit" name="getnumberid" class="btn btn-success">
                      </form>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div> <!-- end of modal here-->
              <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="editmarks" aria-hidden="true" id="editmarks">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 class="modal-title">Edit marks</h4>
                    </div>
                    <div class="modal-body">
                      <form class="" action="<?php echo base_url();?>index.php/addmarks/editmarks" method="post">
                        <div class="form-group">
                          <label for="student number">Student number</label>
                          <input type="text" name="candidatenumberid" value="" id="candidatenumberid" class="form-control" required>
                        </div>
                        <div class="form-group">
                          <label for="module">Module Code</label>
              						<select name="moduleidcode" class="form-control" id="moduleidcode">
              							<option value="">Select Module...</option>
              							<?php foreach($modules as $each){ ?>
                            <option value="<?php echo $each->module_id; ?>"><?php echo $each->module_code; ?></option>';<?php } ?>
              						</select>
                        </div>
                        <div class="form-group">
                          <label for="marksadd">Marks</label>
                          <input type="number" name="marksdataid" value="" id="marksdataid" class="form-control">
                        </div>
                        <div class="form-group">
                          <label for="marksdate">Marks submited date</label>
                          <input type="text" name="marksdatetime" value="" class="form-control" id="marksdatetime" required placeholder="yyy-mm-dd" pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" title="Enter Date in format: yyy-mm-dd">
                        </div>
                        <input type="submit" name="getmarksid" value="Save" name="getmarksid" class="btn btn-primary">
                      </form>
                    </div>
                  </div>
                </div>
              </div><!-- end of modal here-->
              <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="addmarks" aria-hidden="true" id="addmarks"><!-- add student marks -->
                <div class="modal-dialog">
                  <!-- Modal content-->
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 class="modal-title">Add student marks</h4>
                    </div>
                    <div class="modal-body">
                      <form class="" action="<?php echo base_url();?>index.php/addmarks/studentMarks" method="post">
                        <div class="form-group">
                          <label for="student number">Student number</label>
                          <input type="text" name="candidatenumberid" value="" id="candidatenumberid" class="form-control" required>
                        </div>
                        <div class="form-group">
                          <label for="module">Module Code</label>
              						<select name="moduleidcode" class="form-control" id="moduleidcode">
              							<option value="">Select Module...</option>
              							<?php foreach($modules as $each){ ?>
                            <option value="<?php echo $each->module_id; ?>"><?php echo $each->module_code; ?></option>';<?php } ?>
              						</select>
                        </div>
                        <div class="form-group">
                          <label for="marksadd">Marks</label>
                          <input type="number" name="marksdataid" value="" id="marksdataid" class="form-control">
                        </div>
                        <div class="form-group">
                          <label for="marksdate">Marks submited date</label><span>(Consider to enter a valid date)</span>
                          <input type="text" name="marksdatetime" value="" class="form-control" id="marksdatetime" required placeholder="yyy-mm-dd" pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" title="Enter Date in format: yyy-mm-dd">
                        </div>
                        <input type="submit" name="getmarksid" value="Save" name="getmarksid" class="btn btn-primary">
                      </form>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div><!-- end of modal-->
              <div class="form_error">
                <?php echo validation_errors('<div class="alert alert-danger" style="height:1px;">','</div>');?>
              </div>
              <div style="color:red; padding-bottom:30px;">
    						<?php
    						if (isset($error_file_upload)) {
                  ?>
                  <script type="text/javascript">
                    var errorFile='<?php echo $error_file_upload; ?>';
                    alert(errorFile);
                  </script>
                  <?php
    						}
    						if (isset($minimum_upload)) {
    							echo $minimum_upload;
    						}
    						?>
    					</div>
              <div class="">
                <?php
                if (!empty($validsearch) && $validsearch==true) {
                  ?>
                  <!-- BUTTON HERE-->
                  <div class="modal fade" id="myModal" role="dialog">
                    <div class="modal-dialog">
                      <!-- Modal content-->
                      <div class="modal-content">
                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                          <h4 class="modal-title">Search result</h4>
                        </div>
                        <div class="modal-body">
                          <?php require_once(APPPATH.'views/tempuser/data.php');?>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <?php
                }
                ?>
              </div>
            <!-- Modal -->
            <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="application-details" aria-hidden="true" id="application-details"><!-- add student marks -->
              <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add student account</h4>
                  </div>
                  <div class="modal-body">
                  <form name="userregistermain" action="<?php echo base_url();?>index.php/tempLoad/RegisterMainData" id="userregistermain" method="post">
                      <div class="form-group">
                          <label for="inputEmail">Email</label><span id="email_err_msg" style="color:red;"></span>
                          <input type="email" class="form-control" name="CandidateEmail" id="CandidateEmail" required>
                      </div>
                      <div class="form-group">
                          <label for="Email">Confirm Email</label>
                          <input type="text" class="form-control" name="CandidateEmailConfirm" id="CandidateEmailConfirm" required>
                          <span id="password_err_msg" class="spanstyle"></span>
                      </div>
                      <div class="form-group">
                        <label for="firstname">Firstname</label><span id="error_fname" style="color:red;"></span>
                        <input type="text" name="CandidateFname" class="form-control" id="CandidateFname" required>
                      </div>
                      <div class="form-group">
                        <label for="lastname">Lastname</label><span id="error_lname" style="color:red;"></span>
                        <input type="text" name="CandidateLname" class="form-control" id="CandidateLname" required>
                      </div>
                      <div class="form-group">
                          <label for="date">Date of application</label>
                          <input type="text" class="form-control" name="CandidateDate" id="CandidateDate" placeholder="yyy-mm-dd" required>
                          <span id="retypepassword_err_msg" class="spanstyle"></span>
                      </div>
                      <div class=" form-group">
                      <label for="program">Program applyied</label><span id="program_err_msg" style="color:red;"></span>
                      <select name="program" class="form-control" id="program">
                        <option value="">Select program...</option>
                        <?php foreach($groups as $each){ ?>
                        <option value="<?php echo $each->program_code; ?>"><?php echo $each->program_name; ?></option>';<?php } ?>
                      </select>
                     </div>
                    <div class="col-xs-10 col-sm-10 col-md-6 col-lg-6">
                      <input type="submit" name="" value="Create Account"class="btn btn-primary" id="btnsubmit">
                    </div>
                  </form>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>
            </div><!-- end of modal-->
            <!-- Modal -->
            <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="application-details" aria-hidden="true" id="myMarks"><!-- add student marks -->
              <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Student Marks</h4>
                  </div>
                  <div class="modal-body">
                    <table class="table table-sm">
                      <thead>
                        <th>Module Code</th>
                        <th>Module name</th>
                        <th>Marks</th>
                        <th>Grade</th>
                        <th>Submitted date</th>
                      </thead>
                      <tbody>
                        <?php if (isset($_SESSION['registration']) && !empty($marks[0]->points)){
                          foreach ($marks as $values) {
                            echo "<tr>";
                            echo "<td>";
                            echo $values->module_code;
                            echo "</td>";
                            echo "<td>";
                            echo $values->module_name;
                            echo "</td>";
                            echo "<td>";
                            echo $values->points;
                            echo "</td>";
                            echo "<td>";
                            echo $values->letter;
                            echo "</td>";
                            echo "<td>";
                            echo $values->addition_date;
                            echo "</td>";
                            echo "</tr>";
                          }
                        }
                        else {
                          echo "No current marks for selected student";
                        }
                        ?>
                      </tbody>
                    </table>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>
            </div><!-- end of modal-->
            <!-- Modal -->
<div class="modal fade" role="dialog" aria-labelledby="addnewstudent" aria-hidden="true" id="addnewstudent"><!-- add student marks -->
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">New student</h4>
      </div>
      <div class="modal-body">
        <?php require_once(APPPATH.'views/tempuser/personaldata.php'); ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div><!-- end of modal-->

              <!-- Modal -->
              <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="working_experience" aria-hidden="true" id="working_experience"><!-- add student marks -->
                <div class="modal-dialog">
                  <!-- Modal content-->
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 class="modal-title">Church Information</h4>
                    </div>
                    <div class="modal-body">
                      <?php require_once(APPPATH.'views/tempuser/church_experience.php'); ?>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div><!-- end of modal-->

              <!-- Modal -->
              <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="job-experience" aria-hidden="true" id="job-experience"><!-- add student marks -->
                <div class="modal-dialog">
                  <!-- Modal content-->
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 class="modal-title">Work Experience</h4>
                    </div>
                    <div class="modal-body">
                      <?php require_once(APPPATH.'views/tempuser/job_experience.php'); ?>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div><!-- end of modal-->

              <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="file-uploads" aria-hidden="true" id="file-uploads"><!-- add student marks -->
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 class="modal-title">Documents Upload</h4>
                    </div>
                    <div class="modal-body">
                      <?php require_once(APPPATH.'views/tempuser/fileuploads.php');?>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>

            </div>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url() ?>css_scripts/vendor/metisMenu/metisMenu.min.js"></script>
    <script src="<?php echo base_url() ?>css_scripts/vendor/jquery/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url() ?>css_scripts/vendor/bootstrap/js/bootstrap.min.js"></script>
    <!-- DataTables JavaScript -->
    <script src="<?php echo base_url() ?>css_scripts/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url() ?>css_scripts/vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url() ?>css_scripts/vendor/datatables-responsive/dataTables.responsive.js"></script>
    <!-- Custom Theme JavaScript -->
  <script src="<?php echo base_url() ?>css_scripts/dist/js/sb-admin-2.js"></script>
    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </s collapsecript>
</body>
<div class="">

</div>
</html>
