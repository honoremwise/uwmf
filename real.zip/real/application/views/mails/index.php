<?php
require('mail.php');
return sendMail('hmwiseneza@gmail.com',"test", "this is to test whether the msg can be sent on ");
?>