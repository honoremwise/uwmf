
<header class="site-header"> <nav class="navbar navbar-default">
<div class="top-line">
	 <div class="container">
			 <div class="row">
					 <div class="col-md-6 col-sm-6 col-xs-6">
							 <p> <span><i class="fa fa-phone"></i><a href="tel:0123 - 45678">0123 - 45678</a></span> <span><i class="fa fa-envelope-o"></i><a href="mailto:info@company.com">info@company.com</a></span> </p>
					 </div>
					 <div class="col-md-6 col-sm-6 col-xs-6 text-right">
							 <p> <span><i class="fa fa-certificate"></i><a href="certificates.html">Our Certifications</a></span> <span><i class="fa fa-file-pdf-o"></i><a href="brochure.pdf">Download Brochure</a></span> </p>
					 </div>
			 </div>
	 </div>
</div>
<div class="header-inner">
	 <div class="container">
			 <div class="row">
					 <div class="col-md-12">
							 <div class="brand"> <a href="#">
									 <h1>Logo</h1>
									 </a> </div>
							 <nav  id="nav-wrap" class="main-nav"> <a id="toggle-btn" href="#"><i class="fa fa-bars"></i> </a>
							 <ul class="sf-menu">
									 <li class="current"> <a href="index.html">Home</a> </li>
									 <li> <a href="about-us.html">About Us </a></li>
									 <li> <a href="products.html">Products</a></li>
									 <li> <a href="exports.html">Exports</a></li>
									 <li> <a href="clients.html">Clients</a> </li>
									 <li> <a href="contact.html">Contact</a> </li>
							 </ul>
							 </nav> </div>
			 </div>
	 </div>
</div>
</nav>
<div class="container">
	 <div class="row" style="color:white;">
	 	</div>
</div>
</header>
<div class="container">
	 <div class="row">

	 </div>
</div>
