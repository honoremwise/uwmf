<h5 style="color: #fff">Copy rights UWMF&copy;.<?php echo date('Y'); ?>&nbsp;&nbsp;All rights reserved</h5>
