<div class="row">
  <div class="form-group col-xs-10 col-sm-10 col-md-3 col-lg-3">
    <label for="firstname">Firstname</label>
    <input type="text" name="CandidateFname" value="<?php echo $fname; ?>" class="form-control" id="input1">
  </div>
  <div class=" form-group col-xs-10 col-sm-10 col-md-3 col-lg-3">
    <label for="lastname">Lastname</label>
    <input type="text" name="CandidateLname" class="form-control" value="<?php echo $lname; ?>" id="input2">
  </div>
  <div class="form-group col-xs-10 col-sm-10 col-md-3 col-lg-3">
    <label for="telephone">Telephone</label>
    <input type="number" name="CandidatePhone" class="form-control" value="<?php echo $tel; ?>" id="input3">
  </div>
  <div class="form-group col-xs-10 col-sm-10 col-md-3 col-lg-3">
    <label for="IDNumber">ID Number/Passport</label>
    <input type="text" name="CandidateIDnumber" class="form-control" value="<?php echo $passport;  ?>" id="input4">
  </div>
</div>
