<?php
$CI = &get_instance();
$CI->load->database();
$host= $CI->db->hostname;
$pass=$CI->db->password;
$user=$CI->db->username;
$myconnection= mysqli_connect($host,$user,$pass,'uwmf');
if ($myconnection && isset($_SESSION['username'])) {
  // get all required file to be downloaded by an applicant
  $files=$CI->db->get_where('files');
  $elements=$files->result_array();
  if (count($elements)>0) {
    foreach ($files->result() as $rows) {
      if (strpos($rows->file_name,'statement')>2) {
        $faith=$rows->file_name;
      }
      if (strpos($rows->file_name,'recommend')>2) {
        $recommend=$rows->file_name;
      }
    }
  }else {
    // code...
  }
} else {
  die('Could not establish the server connection');
}
 ?>
