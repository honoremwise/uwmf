<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>UWMF-MIS-University application</title>
    <link rel="stylesheet" type="text/css" href="<?php  echo base_url() ?>css_scripts/vendor/bootstrap/css/bootstrap.min.css">
  </head>
  <body class="container">
    <div class="row" style="margin:100px;">
      <div class="col-xs-10 col-sm-10 col-md-3 col-lg-3"></div>
      <div class="col-xs-10 col-sm-10 col-md-6 col-lg-6">
        <img src="<?php  echo base_url() ?>css_scripts/vendor/datatables/images/test.png" width="200" height="150" class="img-circle">
      </div>
      <div class="col-xs-10 col-sm-10 col-md-3 col-lg-3"></div>
    </div>
    <div class="row">
      <div class="col-xs-10 col-sm-10 col-md-2 col-lg-2"></div>
      <div class="col-xs-10 col-sm-10 col-md-6 col-lg-6">
        <h4>
          Account successfuly created <a href="<?php echo base_url(); ?>index.php/loadPages">Login</a> with your email and password.
        </h4>
      </div>
      <div class="col-xs-10 col-sm-10 col-md-2 col-lg-2"></div>
    </div>
  </body>
</html>
