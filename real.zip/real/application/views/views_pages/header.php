<!DOCTYPE html>
<html>
<head>
	<title>application</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css_scripts/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo(base_url()) ?>css_scripts/css_custom_pages/page_header.css">
  <script type="text/javascript" src="<?php  echo base_url() ?>css_scripts/vendor/jquery/jQuery.js"></script>
	<script type="text/javascript" src="<?php  echo base_url() ?>css_scripts/js/custom.js"></script>
	<style media="screen">
		.spanstyle{
			color: red;
		}
	</style>
</head>
<header class="site-header"> <nav class="navbar navbar-default">
<div class="topline">
	 <div class="container">
			 <div class="row">
					 <div class="col-md-6 col-sm-6 col-xs-6">
							 <p> <span><i class="fa fa-phone"></i><a href="tel:(+250)788-554109">(+250)788-554109</a></span> <span><i class="fa fa-envelope-o"></i><a href="mailto:missionfrontiers@yahoo.com">missionfrontiers@yahoo.com</a></span> </p>
					 </div>
					 <div class="col-md-6 col-sm-6 col-xs-6 text-right">
							 <p> <span><i class="fa fa-certificate"></i><a href="certificates.html">Our Certifications</a></span> <span><i class="fa fa-file-pdf-o"></i><a href="brochure.pdf">Download Application Guide</a></span> </p>
			 </div>
	 </div>
</div>
<nav class="navbar navbar-default navbar-static-top" role="navigation">
					<ul class="nav navbar-top-links navbar-right">
							<li></li>
							<li class="dropdown">
									<a class="dropdown-toggle" data-toggle="dropdown" href="#">
											<i class="fa fa-envelope fa-fw"></i> <i class="fa fa-caret-down"></i>
									</a>
									<ul class="dropdown-menu dropdown-messages">
											<li>
													<a href="#">
															<div>
																	<strong>Inquiry on application</strong>
															</div>
															<div>Email:admissions@gmail.com</div>
													</a>
											</li>
											<li class="divider"></li>
											<li>
													<a href="#">
															<div>
																	<strong>Inquiry on application</strong>
															</div>
															<div>Tel:078823250</div>
													</a>
											</li>
									</ul>
							</li>
							<li class="dropdown">
									<a class="dropdown-toggle" data-toggle="dropdown" href="#">
											<i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
									</a>
									<ul class="dropdown-menu dropdown-user">
											<li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
											</li>
											<li class="divider"></li>
											<li><a href="<?php echo base_url();?>index.php/loadPages/ResumeApplication"><i class="fa fa-sign-out fa-fw"></i> Login</a>
											</li>
									</ul>
							</li>
					</ul>
			</nav>
</div>
</header>
