<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<?php $this->load->view('views_pages/header.php');
require_once(APPPATH.'views/views_pages/include.php');
?>
<body style="background-color:#286090;"><!-- background-color:#666-->
	<div class="fakenav">
		<div class="container">
			<h4 style="color: #fff">University application</h4>
		</div>
	</div>
	<div class="container">
		<div class="form_error">
			<?php echo validation_errors('<div class="alert alert-danger" style="height:1px;">','</div>');?>
		</div>
		<div class="jumbotron">
			<div class="row" style="color:red;">
				<?php if (isset($erroruser)) {
					echo $erroruser;
				}?>
			</div>
			<div class="row jumbotron-content">
				<h3>Create an account</h3><br>
				<form name="userregistermain" action="<?php echo base_url();?>index.php/saveRegister/RegisterMainData" id="userregistermain" method="post">
				    <div class="form-group">
				        <label for="inputEmail">Email</label>
				        <input type="email" class="form-control" name="CandidateEmail" placeholder="Email" id="CandidateEmail">
								<span id="email_err_msg" class="spanstyle"></span>
				    </div>
				    <div class="form-group">
				        <label for="inputPassword">Password</label>
				        <input type="password" class="form-control" name="CandidatePassword" placeholder="Password" id="CandidatePassword">
								<span id="password_err_msg" class="spanstyle"></span>
				    </div>
						<div class="form-group">
				        <label for="inputPassword">Confirm Password</label>
				        <input type="password" class="form-control" name="CandidatePasswordConf" placeholder="Password" id="CandidatePasswordConf">
								<span id="retypepassword_err_msg" class="spanstyle"></span>
				    </div>
						<div class=" form-group">
						<label for="program">Program applying for</label>
						<select name="program" class="form-control" id="program">
							<option value="">Select program...</option>
							<?php foreach($groups as $each){ ?>
              <option value="<?php echo $each->program_code; ?>"><?php echo $each->program_name; ?></option>';<?php } ?>
						</select>
						<span id="program_err_msg" class="spanstyle"></span>
					</div>
					  <input type="submit" name="" value="Create Account"class="btn btn-primary" id="btnsubmit">
				</form>
			</div>
		</div>
		<?php require_once(APPPATH.'views/views_pages/copy.php'); ?>
	</div>
</body>
</html>
