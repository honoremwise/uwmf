<?php include('include.php');
require_once(APPPATH.'views/certificate/datareview.php');
require_once(APPPATH.'views/views_pages/pageheader.php');
require_once(APPPATH.'views/views_pages/getdownloads.php');
?>
	<div class="container">
		<h5 style="color:white;">Please upload the following documents only birth certificate is optional</h5>
		<div class="jumbotron">
      <?php echo validation_errors('<div class="alert alert-danger" style="height:1px;">','</div>');?>
			<div class="row jumbotron-content">
					<div style="color:red;">
						<?php
						if (isset($error_file_upload)) {
							echo $error_file_upload;
						}
						if (isset($minimum_upload)) {
							echo $minimum_upload;
						}
						?>
					</div>
					<div class="row">
						<div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
							<form action="<?php echo base_url();?>index.php/identityFiles/saveFiles"  method="post" enctype="multipart/form-data">
								<div class="form-group">
									<label for="candidateIDnumber">Identity/Passport</label>
									<input type="file" name="identity" class="form-control">
								</div>
								<input type="submit" class="btn  btn-success btn-sm" value="Upload file">
								<span>
									<?php if (!empty($row->scanned_id)) {
										?>
										<a href="<?php echo base_url().'profiles/'.$row->scanned_id; ?>" target="_blank">Preview file</a>
										<?php
									} ?>
									</span>
							</form>
						</div>
						<div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
							<form  action="<?php echo base_url();?>index.php/pictureFiles/saveFiles" method="post" enctype="multipart/form-data">
              <div class="form-group">
								<label for="profile ">Profile Picture</label>
								<input type="file" name="picture" class="form-control">
							</div>
							<input type="submit" class="btn  btn-success btn-sm" value="Upload file">
							</form>
						</div>
						<div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
							<form action="<?php echo base_url();?>index.php/degreeFiles/saveFiles"  method="post" enctype="multipart/form-data">
							 <div class="form-group">
								 <label for="candidateDiploma">Degree/Diploma</label>
								 <input type="file" name="candidatediploma" class="form-control">
							 </div>
							 <input type="submit" class="btn  btn-success btn-sm" value="Upload file">
							 <span>
								 <?php if (!empty($row->degree_copy)) {
								 	?><a href="<?php echo base_url().'profiles/'.$row->degree_copy; ?>" target="_blank">Preview file</a>
									<?php
								 } ?>
							 </span>
							</form>
						</div>
						<div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
							<form action="<?php echo base_url();?>index.php/motivationFiles/saveFiles"  method="post" enctype="multipart/form-data">
								<div class="form-group">
									<label for="candidatemotivation">Autobiographical Essay</label>
									<input type="file" name="candidatemotivation" class="form-control">
								</div>
								<input type="submit" class="btn  btn-success btn-sm" value="Upload file">
								<span>
									<?php if (!empty($row->motivation_letter)) {
									 ?><a href="<?php echo base_url().'profiles/'.$row->motivation_letter; ?>" target="_blank">Preview file</a>
									 <?php
									} ?>
								</span>
							</form>
						</div>
						<div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
							<form action="<?php echo base_url();?>index.php/birthcertificateFiles/saveFiles"  method="post" enctype="multipart/form-data">
								<div class="form-group">
									<label for="candidateBirth">Birth Certificate</label>
									<input type="file" name="candidateBirth" class="form-control">
								</div>
								<input type="submit" class="btn  btn-success btn-sm" value="Upload file">
								<span>
									<?php if (!empty($row->birth_certificate) && $row->birth_certificate!='N/A') {
									 ?><a href="<?php echo base_url().'profiles/'.$row->birth_certificate; ?>" target="_blank">Preview file</a>
									 <?php
									} ?>
								</span>
							</form>
						</div>
						<div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
							<form action="<?php echo base_url();?>index.php/recommendationFiles/saveFiles" method="post" enctype="multipart/form-data">
								<div class="form-group">
									<label for="candidateBirth">Recommendation</label>
									<input type="file" name="candidateRecomm" class="form-control">
								</div>
								<input type="submit" class="btn  btn-success btn-sm" value="Upload file">
								<span>
									<?php
									if (!empty($row->recomm_letter)) {
										?>
										<a href="<?php echo base_url().'profiles/'.$row->recomm_letter; ?>" target="_blank">Preview file</a>
										<?php
									}
									 ?>
								</span>
							</form>
						</div>
					</div>
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
							<form class="" action="<?php echo base_url();?>index.php/transcriptFiles/saveFiles" method="post" enctype="multipart/form-data">
								<div class="form-group">
									<label for="transcriptupload">Academic transcripts</label><span>Upload all transcripts within a single file if you have different copies,zipped files are not allowed</span>
									<input type="file" name="candidatereport" class="form-control">
								</div>
								<input type="submit" class="btn  btn-success btn-sm" value="Upload file">
								<span>
									<?php
									if (!empty($row->transcript)) {
										?>
										<a href="<?php echo base_url().'profiles/'.$row->transcript; ?>" target="_blank">Preview file</a>
										<?php
									}
									 ?>
								</span>
							</form>
						</div>
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
							<form class="" action="<?php echo base_url();?>index.php/transcriptFiles/savefaith" method="post" enctype="multipart/form-data">
								<div class="form-group">
									<label for="statement of faith">Statement of faith</label><span>Upload a signed Statement of faith found on our downloads page &nbsp;<a href="#addfile" data-toggle="modal" data-target="#addfile">Download</a></span>
									<input type="file" name="candidatereport" class="form-control">
								</div>
								<input type="submit" class="btn  btn-success btn-sm" value="Upload file">
								<span>
									<?php
									if (!empty($row->statement_faith)) {
										?>
										<a href="<?php echo base_url().'profiles/'.$row->statement_faith; ?>" target="_blank">Preview file</a>
										<?php
									}
									 ?>
								</span>
							</form>
						</div>
					</div>
					<h5>Recommendation must be from the Senior Pastor of your church or Professor at your previous university<h5/>
					<div class="row">
						<div class="col-xs-10 col-sm-10 col-md-3 col-lg-3"></div>
						<div class="col-xs-10 col-sm-10 col-md-3 col-lg-3">
							<?php echo form_open('application_Files/'); ?>
							<form enctype="multipart/form-data" method="post">
								<input type="hidden" value="6" class="form-control" name="uploadnumber" id="uploadnumber"> <br>
								<input type="submit" class="btn btn-primary pull-right" value="Go Next" style="margin-left:90px;">
							</form>
						</div>
						<div class="col-xs-10 col-sm-10 col-md-3 col-lg-3"></div>
						<div class="col-xs-10 col-sm-10 col-md-3 col-lg-3"></div>
			    </div>
					<div class="modal fade" tabindex="-1" aria-labelledby="addfile" role="modal" aria-hidden="true" id="addfile">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" name="button" class="close" data-dismiss="modal">&times;</button>
									<h4 class="modal-title">Downloads</h4>
								</div>
								<div class="modal-body">
									<table class="table table-condensed">
										<thead>

										</thead>
										<tbody>
											<tr>
												<td>Statement of faith</td>
												<td>
													<?php if (!empty($faith)) {
														?>
														<a href="<?php echo base_url().'files/'.$faith; ?>" target="_blank">View</a><?php
													} ?>
												</td>
											</tr>
											<tr>
												<td>Recommendation letter format</td>
												<td>
													<?php if (!empty($recommend)) {
														?>
														<a href="<?php echo base_url().'files/'.$recommend; ?>" target="_blank">View</a><?php
													} ?>
												</td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div><!-- end of modal-->
		</div>
	</div>
	<h5 style="color: #fff">&copy;copy rights UWMF <?php echo date('Y'); ?></h5>
</body>
</html>
