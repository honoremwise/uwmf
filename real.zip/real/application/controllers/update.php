<?php
class update extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
		$this->load->helper('url');
		$this->load->helper('security');
    $this->load->library('form_validation');
		$this->load->model('selectModels');
    $this->load->Model('selectPrograms');
  }
  public function index()
  {
    //check if sessions are valid
    if (!isset($_SESSION['username'])){
      $data=array(
        'messageDisplay'=>'Session expired,Please login',
      );
      $this->load->view('views_pages/home.php',$data);
    }else {
      //chek whether form data has been previously saved
      if(isset($_GET['submitMainupdate'])) {
        $this->save_update();
      }
      elseif(isset($_GET['churchexperienceupdate'])) {
        //chek whether user has submitted his/her relious position information
        $this->saveexperience();
      }elseif (isset($_GET['workexperienceupdate'])){
        // check whether applicant has submitted work experience
        $this->saveworkexperience();
      }elseif (isset($_GET['fileseupdate'])) {
        // redirect to file uploads page
        //get progra for the current applicant
        $user=$this->session->userdata('username');
        //check data from database
        $result=$this->selectModels->saveData($user);
        switch ($result) {
          case '01':
            $this->load->view('views_pages/cert_diploma_program_uploads.php');
            break;
          case '02':
            $this->load->view('views_pages/cert_diploma_program_uploads.php');
            break;
          case '03':
            $this->load->view('views_pages/bachelor_master_program_uploads.php');
            break;
          case '04':
            $this->load->view('views_pages/bachelor_master_program_uploads.php');
            break;
          default:
            $this->load->view('views_pages/home.php');
            break;
        }
      }else {
        $this->load->view('views_pages/home.php');
      }
    }
  }
  public function save_update()
  {
    $user=$this->session->userdata('username');
    //check data from database
    $result=$this->selectModels->saveData($user);
    if ($result!=FALSE) {
      // redirect to update file
      $branches=$this->selectPrograms->university_branches();
      $data=array(
        'branches'=>$branches,
      );
      switch ($result) {
        case '01':
          $this->load->view('certificate/application.php',$data);
          break;
        case '02':
          $this->load->view('certificate/application.php',$data);
          break;
        case '03':
          $this->load->view('bachelor_master/application.php',$data);
          break;
        case '04':
          $this->load->view('bachelor_master/application.php',$data);
          break;
        default:
          $this->load->view('views_pages/home.php');
          break;
      }
    }else { // redirect back to the login page
      $this->load->view('views_pages/home.php');
    }
  }//end of function definition
  public function saveexperience()
  {
    //get reference for the current applicant
    $this->load->model('Certificate_saveFiles');
    $reference=$this->Certificate_saveFiles->retrieveReference();
    //check data from database
    $result=$this->selectModels->savework($reference);
    if ($result!=FALSE) {
      switch ($result) {
        case '01':
          $this->load->view('certificate/work_experience.php');
          break;
        case '02':
          $this->load->view('certificate/work_experience.php');
          break;
        case '03':
          $this->load->view('bachelor_master/work_experience.php');
          break;
        case '04':
          $this->load->view('bachelor_master/work_experience.php');
          break;
        default:
          $this->load->view('views_pages/home.php');
          break;
      }
    }else {
      $this->load->view('views_pages/home.php');
    }
  }//end of function
  public function saveworkexperience()
  {
    //get reference for the current applicant
    $this->load->model('Certificate_saveFiles');
    $reference=$this->Certificate_saveFiles->retrieveReference();
    //check data from database
    $result=$this->selectModels->checkexperience($reference);
    if ($result!=FALSE) {
      switch ($result) {
        case '03':
        $this->load->view('bachelor_master/job_work_experience.php');
          break;
        case '04':
          $this->load->view('bachelor_master/job_work_experience.php');
          break;
        default:
          $this->load->view('views_pages/home.php');
          break;
      }
    }else {
      $this->load->view('views_pages/home.php');
    }
  }//end of function
}
 ?>
