<?php
/**
 *This class deals with uploading files for existing students who did not apply using the system
 */
class Files extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->helper('url');
    $this->load->helper('form');
    $this->load->helper('file');
    $this->load->library('form_validation');
    $this->load->model('Certificate_saveFiles');
    $this->load->model('SelectPrograms');
    $this->load->model('TempModels');
    $this->load->model('Student');
  }
  public function index()
  {
    if (!isset($_SESSION['username'])){
      $data=array('session' => 'You are logged out');
      $this->load->view('index.php',$data);
    }else {
      $data=array('session' => 'You are logged out');
      $this->load->view('index.php',$data);
    }
  }//end of function
  public function savePicture()
  {
    $reference=$this->Certificate_saveFiles->retrieveReference(); //getting current student reference
    $config['upload_path'] ='./profiles/';
    $config['allowed_types']='gif|jpg|png|jpeg';
    $file=$_FILES['picture']['name'];
    $config['max_size']     =1000;
    $this->form_validation->set_rules('picture', '', 'callback_checkUploadne');
    if ($this->form_validation->run()==TRUE) {
      $user=$_SESSION['username'];
      $type= pathinfo($_FILES['picture']['name'], PATHINFO_EXTENSION);
      $config["file_name"] = $reference."_photo.".$type;
      $file= $reference."_photo.".$type;
      $this->load->library('upload', $config);
      $checkExisting=$_SERVER['DOCUMENT_ROOT'].'/real/profiles/'.$file;
      if (count($checkExisting)!=0) {
        //delete the file
        @unlink($checkExisting);
      }else {

      }
      $save = $this->upload->do_upload('picture');
      if ($save==FALSE) {
        $error = array('error_file_upload' => $this->upload->display_errors());
        //get candidate program to know which upload page to direct
        $program=$this->SelectPrograms->applicantProgram(); //not needed here
        $this->load->view('user/index.php',$error);
      }else {
        $save = $this->upload->data("file_name");
        $data = array('upload_data' => $this->upload->data());
        $field='photo';
        //save the file name in database
        $save=$this->Student->profilepicture($file,$field);
        if ($save==true||$save==false) {
          $this->load->view('user/index.php');
        }
      }
    } else {// validation error
      $err = array('error' => 'Invalid file type for profile picture');
      $this->load->view('user/index.php',$err);
    }
  }//end of function
  //function to validate file
  public function checkUploadne(){
    $allowed_mime_type_arr= array('image/jpeg','image/jpg','image/png','image/x-png');
    //get all files required to be uploaded
    if (isset($_FILES['picture']['name'])) {
      $mime=get_mime_by_extension($_FILES['picture']['name']);
      if (isset($_FILES['picture']['name']) && $_FILES['picture']['name']!="") {
        if (in_array($mime,$allowed_mime_type_arr)){
          return true;
        }else {
          $this->form_validation->set_message('checkUploadne', 'Please select only  file of type jpg or png image');
          return false;
        }
      } else {
        $this->form_validation->set_message('checkUploadne','upload required file');
        return false;
      }
    } else {
      $this->form_validation->set_message('checkUploadne', 'Please choose a file to upload.');
      return false;
    }
  }//end of function
  //function definition
  public function saveid() //upload id/passport
  {
    if (count($_FILES)==1) {
      foreach ($_FILES as $key => $value) {
        $fileuse=$key;
      }
      $config['upload_path'] ='./profiles/';
      $config['allowed_types']='pdf';
      $config['max_size']      =1000;
      $file=$_FILES[$fileuse]['name'];
      $this->form_validation->set_rules($fileuse, '', 'callback_checkfile');
      if ($this->form_validation->run()==TRUE) {

        $reference=$this->Certificate_saveFiles->retrieveReference(); //getting current student reference
        if ($reference!=false) { //correct reference number
          $type= pathinfo($_FILES[$fileuse]['name'], PATHINFO_EXTENSION);
          $config["file_name"] = $file= $reference.$fileuse.".".$type;
          //$file= $reference."_".$fileuse;
          $file= $reference.$fileuse.".".$type;
          $this->load->library('upload', $config);
          $checkExisting=$_SERVER['DOCUMENT_ROOT'].'/real/profiles/'.$file;
          if (count($checkExisting)!=0) {
            //delete the file
            @unlink($checkExisting);
          }else {
          }
          $save = $this->upload->do_upload($fileuse);
          if ($save==FALSE) {
            $error = array('error_file_upload' => $this->upload->display_errors());
            //redirect to uploads page display and correct errors
            $this->load->view('user/index.php',$error);
          }else {
            $save = $this->upload->data("file_name");
            $data = array('upload_data' => $this->upload->data());
            if (strpos($file,"identity")) {
              $field='scanned_id';
            } if (strpos($file,"candidatediploma")) {
              $field='degree_copy';
            }if (strpos($file,"candidateRecomm")) {
              $field='recomm_letter';
            }if (strpos($file,"candidatereport")) {
              $field="transcript";
            }if (strpos($file,"candidatestatement")){
              $field="statement_faith";
            }if (strpos($file,"candidatemotivation")) {
              $field="motivation_letter";
            }if (strpos($file,"candidateBirth")){
              $field="birth_certificate";
            }
            //save the file name in database
            $save=$this->Student->profilepicture($file,$field);
            if ($save!=false){
      				$data=array(
      					'success'=>'File successfuly uploaded',
      				);
      				$this->load->view('user/index.php',$data);
            }else{
      				$data=array(
      					'error'=>'File upload error, try again',
      				);
      				$this->load->view('user/index.php', $data);
            }
          }
        }else {//error of getting reference
  				$data=array(
  					'error'=>'Invalid upload, try again',
  				);
  				$this->load->view('user/index.php', $data);
        }
      } else {
        $this->load->view('user/index.php');
      }
    } else {
      $this->load->view('user/index.php');
    }
  }//end of function
  //function to validate file
  public function checkfile(){
    if (count($_FILES)==1) {
      foreach ($_FILES as $key=>$value) {
        $name=$key;
      }
      $allowed_mime_type_arr= array('application/pdf');
      //get all files required to be uploaded
      if (isset($_FILES[$name]['name'])){
        $mime=get_mime_by_extension($_FILES[$name]['name']);
        if (isset($_FILES[$name]['name']) && $_FILES[$name]['name']!="") {
          if (in_array($mime,$allowed_mime_type_arr)) {
            return true;
          }else {
            $this->form_validation->set_message('checkfile', 'Please select only  file of type pdf');
            return false;
          }
        } else {
          $this->form_validation->set_message('checkfile','upload required file');
          return false;
        }
      } else {
        $this->form_validation->set_message('checkfile', 'Please choose a file to upload.');
        return false;
      }
    } else {
      $data=array(
        'error'=>'Upload error occured, try again',
      );
      $this->load->view('user/index.php', $data);
    }
  }//end of function
}
?>
