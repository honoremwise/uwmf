<?php
/**
 * add students marks
 */
class addmarks extends CI_Controller
{

  function __construct()
  {
    parent::__construct();
		$this->load->helper('url');
		$this->load->library('form_validation');
    $this->load->model('selectModels');
    $this->load->model('tempModels');
    $this->load->model('selectPrograms');
  }
  public function index()
  {
    $this->load->view('tempuser/home.php');
  }
  public function studentMarks()
  {
    // validate form for input
    $this->form_validation->set_rules('candidatenumberid','Student number','trim|required');
    $this->form_validation->set_rules('moduleidcode','Module Code'.'trim|required');
    $this->form_validation->set_rules('marksdataid','Marks','trim|required|is_natural|min_length[2]|max_length[3]');
    $this->form_validation->set_rules('marksdatetime','Marks submited date','trim|required');
    if ($this->form_validation->run()!=FALSE) {
      $studentnumber=$this->input->post('candidatenumberid');
      $modulecode=$this->input->post('moduleidcode');
      $marks=$this->input->post('marksdataid');
      $marksgetdate=$this->input->post('marksdatetime');
      //check if student number already in database
      $data=array(
        'registration_no'=>$studentnumber,
        'points'=>$marks,
        'user'=>$_SESSION['validuser'],
        'date'=>$marksgetdate,
    );
      $check=$this->tempModels->checkuser($data);
      if ($check!=FALSE) {
        // insert marks
        $data=array('registration_no'=>$studentnumber,
        'points'=>$marks,
        'addition_date'=>$marksgetdate,
        'module_id'=>$modulecode,
        'user_id'=>$check[0],
        'grade'=>$check[1],
      );
      $insert=$this->tempModels->addMarks($data);
      if ($insert==false) {
        $data=array(
  				'groups'=>$this->selectPrograms->university_programs(),
  				'branches'=>$this->selectPrograms->university_branches(),
  				'modules'=>$this->selectPrograms->university_modules(),
  				'students'=>$this->selectPrograms->university_students(),
  				'recorderror'=>'Unable to save marks try again');
  			  $this->load->view('tempuser/index.php',$data);
      }else {
        $data=array(
  				'groups'=>$this->selectPrograms->university_programs(),
  				'branches'=>$this->selectPrograms->university_branches(),
  				'modules'=>$this->selectPrograms->university_modules(),
  				'students'=>$this->selectPrograms->university_students(),
  				'success'=>'Marks saved');
  			  $this->load->view('tempuser/index.php',$data);
      }
    }else {
        //go back to index
        $data=array(
  				'groups'=>$this->selectPrograms->university_programs(),
  				'branches'=>$this->selectPrograms->university_branches(),
  				'modules'=>$this->selectPrograms->university_modules(),
  				'students'=>$this->selectPrograms->university_students(),
  				'recorderror'=>'Invalid data');
  			  $this->load->view('tempuser/index.php',$data);
      }
   }else {
     $data=array(
       'groups'=>$this->selectPrograms->university_programs(),
       'branches'=>$this->selectPrograms->university_branches(),
       'modules'=>$this->selectPrograms->university_modules(),
       'students'=>$this->selectPrograms->university_students(),
     );
       $this->load->view('tempuser/index.php',$data);
    }
  }//end of function
  public function editmarks()
  {
    if (isset($_SESSION['validuser'])) {
      $this->form_validation->set_rules('candidatenumberid','Student number','trim|required');
      $this->form_validation->set_rules('moduleidcode','Module Code'.'trim|required');
      $this->form_validation->set_rules('marksdataid','Marks','trim|required|is_natural|min_length[2]|max_length[3]');
      $this->form_validation->set_rules('marksdatetime','Marks submited date','trim|required');
      if ($this->form_validation->run()!=FALSE) {
        //check if student has marks in the submitted module
        $data=array(
        'registration_no'=>$this->input->post('candidatenumberid'),
        'module_id'=>$this->input->post('moduleidcode'),
        'marks'=>$this->input->post('marksdataid'),
        'date'=>$this->input->post('marksdatetime'),
        );
        $check=$this->tempModels->checkMarks($data);//check and update marks
        if ($check!=FALSE) {
          $data=array(
    				'groups'=>$this->selectPrograms->university_programs(),
    				'branches'=>$this->selectPrograms->university_branches(),
    				'modules'=>$this->selectPrograms->university_modules(),
    				'students'=>$this->selectPrograms->university_students(),
    				'success'=>'Marks updated');
    			  $this->load->view('tempuser/index.php',$data);
        } else {
          $data=array(
    				'groups'=>$this->selectPrograms->university_programs(),
    				'branches'=>$this->selectPrograms->university_branches(),
    				'modules'=>$this->selectPrograms->university_modules(),
    				'students'=>$this->selectPrograms->university_students(),
    				'recorderror'=>'Data do not match previous record to update');
            unset($_SESSION['username']);
    			  $this->load->view('tempuser/index.php',$data);
        }
      }else {
        $data=array(
  				'groups'=>$this->selectPrograms->university_programs(),
  				'branches'=>$this->selectPrograms->university_branches(),
  				'modules'=>$this->selectPrograms->university_modules(),
  				'students'=>$this->selectPrograms->university_students(),
        );
  			  $this->load->view('tempuser/index.php',$data);
      }
    }else {
      $this->load->view('tempuser/home.php');
    }
  }//end of function
}
 ?>
