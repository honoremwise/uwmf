<?php
class adminuser extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
		$this->load->helper('url');
		$this->load->library('form_validation');
    $this->load->model('selectModels');
    $this->load->model('register');
  }
  public function logout(){
    unset($_SESSION['adminuserlogin']);
    $data=array('logout' => 'You are logged out', );
    $this->load->view('admin/home.php',$data);
  }//end of function
  public function index()//check whether all files have been uploaded for master students
  {
    if (!isset($_SESSION['adminuserlogin'])) {
      $this->load->view('admin/home.php');
    }else {
      $this->load->view('admin/index.php');
    }
  }//end of function
  public function account(){
    //validation of the form inputs
    $this->form_validation->set_rules('Useridname','Username','trim|required');
    $this->form_validation->set_rules('useridPassword','Password','trim|required');
    if ($this->form_validation->run()==FALSE) {
      #
      if (isset($this->session->userdata['adminuserlogin'])) {
        # load a page to next page
        $data=array(
        'session'=>'Invalid Session');
        $this->load->view('admin/home.php',$data);
      } else {
        $this->load->view('admin/home.php');
      }
    } else {
      # process data and check if user exist in database
      $user=$this->input->post('Useridname');
      $pass=$this->input->post('useridPassword');
      //check if user exist in database
      $result=$this->selectModels->checkuser($user,$pass);
      //checkLogin is a function in the model called selectModels
      if ($result != FALSE){
        //initialize session
        $this->session->set_userdata('adminuserlogin',$user);
        $data=array(
          'users'=>$this->selectModels->getusers(),
          'positions'=>$this->selectModels->getpositions(),
          'files'=>$this->selectModels->getfiles(),
        );
        $this->load->view('admin/index.php',$data);
      } else {
        $data=array(
          'messageDisplay'=>'Invalid Username or Password',
        );
        //go back to login page
        $this->load->view('admin/home.php',$data);
      }
    }
  }//end of function
  public function addUser()
  {
    $this->form_validation->set_rules('positiontype','','required|trim|alpha');
    if ($this->form_validation->run()!=FALSE) {
      //insert responsability
      $data=array('responsability' => $this->input->post('positiontype'),);
      $add=$this->register->addUsertype($data);
      if ($add!=FALSE) {
        $data=array(
          'users'=>$this->selectModels->getusers(),
          'positions'=>$this->selectModels->getpositions(),
          'files'=>$this->selectModels->getfiles(),
          'success'=>'Record Saved',
        );
        $this->load->view('admin/index.php',$data);
      }else {
        $data=array(
          'users'=>$this->selectModels->getusers(),
          'positions'=>$this->selectModels->getpositions(),
          'files'=>$this->selectModels->getfiles(),
          'recorderror'=>'Unable to save data',
        );
        $this->load->view('admin/index.php',$data);
      }
    }else {
      $data=array(
        'users'=>$this->selectModels->getusers(),
        'positions'=>$this->selectModels->getpositions(),
        'files'=>$this->selectModels->getfiles(),
      );
      $this->load->view('admin/index.php',$data);
    }
  }//add user
  public function addUserdata()
  {
    // validate
    $this->form_validation->set_rules('userfname','','required|trim');
    $this->form_validation->set_rules('userlname','','required|trim|alpha');
    $this->form_validation->set_rules('useremail','','required|trim|valid_email');
    $this->form_validation->set_rules('usertelephone','','required|trim');
    $this->form_validation->set_rules('responsability','','required|trim');
    if ($this->form_validation->run()!=FALSE) {
      // save new user
      $data=array(
        'first_name'=>$this->input->post('userfname'),
        'last_name'=>$this->input->post('userlname'),
        'email'=>$this->input->post('useremail'),
        'telephone'=>$this->input->post('usertelephone'),
        'responsability'=>$this->input->post('responsability'),
      );
      $add=$this->register->addUserdata($data);
      if ($add!=FALSE) {//send an email to choose Username and password
        $data=array(
          'users'=>$this->selectModels->getusers(),
          'positions'=>$this->selectModels->getpositions(),
          'files'=>$this->selectModels->getfiles(),
          'success'=>'Record Saved',
        );
        $this->load->view('admin/index.php',$data);
      }else {
        $data=array(
          'users'=>$this->selectModels->getusers(),
          'positions'=>$this->selectModels->getpositions(),
          'files'=>$this->selectModels->getfiles(),
          'recorderror'=>'Unable to save data',
        );
        $this->load->view('admin/index.php',$data);
      }
    }else {
      $data=array(
        'users'=>$this->selectModels->getusers(),
        'positions'=>$this->selectModels->getpositions(),
        'files'=>$this->selectModels->getfiles(),
      );
      $this->load->view('admin/index.php',$data);
    }
  }//end of function
  public function uploads()
  {
    $this->form_validation->set_rules('fileusetype','File title','required|trim|alpha');
    $test=$this->form_validation->run();
    if (isset($_SESSION['adminuserlogin']) || $test==false) {
      //configure file uploads
      $config['upload_path']   ='./files';
      $config['allowed_types'] ='pdf|doc|png';
      $config['max_size']      =100;
      $type= ".".pathinfo($_FILES['fileuploadid']['name'], PATHINFO_EXTENSION);
      $name=$this->input->post('fileusetype');
      $config["file_name"] ="uwmf_".$name.$type;
      $file="uwmf_".$name.$type;
      $this->load->library('upload',$config);
      if (!$this->upload->do_upload('fileuploadid')) {
        // error in uploading file
        $error=array('errorfile'=>$this->upload->display_errors(),
        'users'=>$this->selectModels->getusers(),
        'positions'=>$this->selectModels->getpositions(),
        'files'=>$this->selectModels->getfiles(),
      );
        $this->load->view('admin/index.php',$error);
      } else {
        // upload file
        $data=array('upload_data'=>$this->upload->data());
        // save file in database
        $data=array(
          'file_name'=>$file,
          'file_usage'=>$this->input->post('fileusetype'),
          'uploaded_date'=>date('Y:m:d'),
        );
        $save=$this->register->savefile($data);
        if ($save!=FALSE) {//file saved
          $data=array(
            'users'=>$this->selectModels->getusers(),
            'positions'=>$this->selectModels->getpositions(),
            'files'=>$this->selectModels->getfiles(),
            'success'=>'file Saved',
          );
          $this->load->view('admin/index.php',$data);
        }else {
          $data=array(
            'users'=>$this->selectModels->getusers(),
            'positions'=>$this->selectModels->getpositions(),
            'files'=>$this->selectModels->getfiles(),
            'recorderror'=>'file not saved',
          );
          $this->load->view('admin/index.php',$data);
        }
      }
    }else {
      $this->load->view('adminuser/home.php');
    }
  }//end of function
  public function statusblock()
  {
    if (!isset($_SESSION['adminuserlogin']) || !isset($_POST['useridvalue'])) {
      $data=array(
        'users'=>$this->selectModels->getusers(),
        'positions'=>$this->selectModels->getpositions(),
        'files'=>$this->selectModels->getfiles(),
      );
      $this->load->view('admin/index.php',$data);
    }else {
      $id=$_POST['useridvalue'];
      $status=$_POST['userstatusid'];
      //block a user
      if ($status=='Active' && isset($_POST['buttonblock'])) {
        $condition=array('email'=>$id,
        'status'=>'Blocked',
      );
      }else {
        $condition=array('email'=>$id,
        'status'=>'Active',
      );
      }
    $status=$this->register->changeStatus($condition);
    if ($status==true) {
      $data=array(
        'users'=>$this->selectModels->getusers(),
        'positions'=>$this->selectModels->getpositions(),
        'files'=>$this->selectModels->getfiles(),
        'success'=>'User status changed',
      );
      $this->load->view('admin/index.php',$data);
    }else {
      $data=array(
        'users'=>$this->selectModels->getusers(),
        'positions'=>$this->selectModels->getpositions(),
        'files'=>$this->selectModels->getfiles(),
        'recorderror'=>'An error occured, try again.',
      );
      $this->load->view('admin/index.php',$data);
    }
    }
  }
}

 ?>
