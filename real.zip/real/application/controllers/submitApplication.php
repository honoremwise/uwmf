<?php
class submitApplication extends CI_Controller
{

  function __construct()
  {
    parent::__construct();
		$this->load->helper('url');
		$this->load->helper('security');
    $this->load->library('form_validation');
		$this->load->model('selectModels');
  }
  public function index()
  {
    // check if session is valid
    if (isset($_SESSION['username'])){
      // get reference number
      $this->load->model('Certificate_saveFiles');
      $reference=$this->Certificate_saveFiles->retrieveReference();
      //get program identification
      $program=$this->selectModels->retrieveprogram();
      //initialize current applicatio year
      $yearapplication=date("Y-m-d");
      //submit application
      $data=array('reference_no' => $reference,
      'program_id'=>$program,
      'year_last_application'=>$yearapplication,
       'number_of_application'=>1,
      );
      $this->load->model('register');
      $this->register->saveApplication($data);
    }else {
      $data=array('session' => 'Invalid session', );
      $this->load->view('views_pages/home.php',$data);
    }
  }
}
 ?>
