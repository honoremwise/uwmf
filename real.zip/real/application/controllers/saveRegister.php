<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class SaveRegister extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->helper('security');
		$this->load->helper(array('form','url'));
		$this->load->helper('email');
		$this->load->model('selectModels');
	}
	public function RegisterMainData()
	{
		function passwordCheck($str){
			if (preg_match("/^(([a-zA-Z]{1,})|([0-9]{1,}))([a-zA-Z]{1,}|([0-9]{1,4}))$/i",$str)) {
				$result=TRUE;
				return $result;
			} else {
				$password=$this->input->post('CandidatePassword');
				$str->form_validation->set_message('passwordCheck','Password must be a combination of alphabets and numbers');
				$result=FALSE;
				return $result;
			}
		}
		$this->form_validation->set_rules('CandidateEmail', 'Email','trim|required|valid_email|xss_clean');
		$this->form_validation->set_rules('CandidatePassword', 'Password', 'required|min_length[8]');
		$this->form_validation->set_rules('CandidatePasswordConf','Confirm Password','required|matches[CandidatePassword]');
		$this->form_validation->set_rules('program','Program applying for','required');

		if ($this->form_validation->run()==FALSE) {
			$this->load->model('selectPrograms');
			$data['groups'] = $this->selectPrograms->university_programs();
			$this->load->view('views_pages/registerFormMain.php', $data);
		} else {
			//Perform database action
			$firstname=$this->input->post('CandidateFname');
			$lastname=$this->input->post('CandidateLname');
			$email=$this->input->post('CandidateEmail');
			$programcode=$this->input->post('program');
			$password=$this->input->post('CandidatePassword');
			//check if password contains alphabets and numbers
			$keywords=str_split($password);
			if ($keywords==true) {
				$elements=array(0,1,2,3,4,5,6,7,8,9);
				$checkexist=0;
				foreach ($keywords as $key => $value) {
					$cmp=array_search($value,$elements);
					if ($cmp!=FALSE) {
						$checkexist=$checkexist+1;
					}else {
						$checkexist+=0;
					}
				}
				if ($checkexist>=1) {
					//check if no email as the input previously saved
					$condition=array('candidate_email'=>$email);
					$check=$this->selectModels->checkuseremail($condition);
					if ($check!=false) {
						$this->load->model('register');
						$data=array(
							'password'=>$password,
							'candidate_email'=>$email,
							 'program_id'=>$programcode,
							'year_registered'=>date('Y-mm-dd'),
						);
						$this->register->registerNew($data);
					} else {
						$this->load->model('selectPrograms');
						$programs=$this->selectPrograms->university_programs();
						$data=array(
							'erroruser'=>'User of the same email already exists, please login',
							'groups'=>$programs,
						);
						$this->load->view('views_pages/registerFormMain.php',$data);
					}
				}else {
					$this->load->model('selectPrograms');
					$programs = $this->selectPrograms->university_programs();
					$data=array(
						'erroruser'=>'Password must be the combination of alphabets and numbers',
						'groups'=>$programs,
					);
					$this->load->view('views_pages/registerFormMain.php',$data);
				}
			}else {
				exit("An error occured, Please try again later");
			}
		}
	}//end of the function
}
 ?>
