<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-08 18:29:51 --> Severity: error --> Exception: syntax error, unexpected ',' /opt/lampp/htdocs/real/application/models/LibModel.php 25
ERROR - 2019-07-08 19:15:32 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) /opt/lampp/htdocs/real/application/views/library/pages/home.php 7
ERROR - 2019-07-08 19:16:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string /opt/lampp/htdocs/real/application/views/library/pages/home.php 8
ERROR - 2019-07-08 19:16:33 --> Severity: 4096 --> Object of class stdClass could not be converted to string /opt/lampp/htdocs/real/application/views/library/pages/home.php 8
ERROR - 2019-07-08 19:47:27 --> Query error: Duplicate entry 'hashdasd' for key 'categ_code' - Invalid query: INSERT INTO `book_categories` (`categ_code`, `categ_name`) VALUES ('hashdasd', 'hasd')
ERROR - 2019-07-08 19:53:10 --> Query error: Duplicate entry 'sajsad' for key 'categ_code' - Invalid query: INSERT INTO `book_categories` (`categ_code`, `categ_name`) VALUES ('sajsad', 'jsdfj')
ERROR - 2019-07-08 20:00:07 --> Query error: Duplicate entry 'sajsad' for key 'categ_code' - Invalid query: INSERT INTO `book_categories` (`categ_code`, `categ_name`) VALUES ('sajsad', 'jsdfj')
ERROR - 2019-07-08 20:02:56 --> Query error: Duplicate entry 'sajsad' for key 'categ_code' - Invalid query: INSERT INTO `book_categories` (`categ_code`, `categ_name`) VALUES ('sajsad', 'jsdfj')
ERROR - 2019-07-08 20:03:04 --> Query error: Duplicate entry 'sajsad' for key 'categ_code' - Invalid query: INSERT INTO `book_categories` (`categ_code`, `categ_name`) VALUES ('sajsad', 'jsdfj')
ERROR - 2019-07-08 20:08:41 --> Query error: Duplicate entry 'sajsad' for key 'categ_code' - Invalid query: INSERT INTO `book_categories` (`categ_code`, `categ_name`) VALUES ('sajsad', 'jsdfj')
ERROR - 2019-07-08 20:15:21 --> Query error: Duplicate entry 'test' for key 'categ_code' - Invalid query: INSERT INTO `book_categories` (`categ_code`, `categ_name`) VALUES ('test', 'tets')
ERROR - 2019-07-08 20:16:46 --> Query error: Duplicate entry 'jhq' for key 'categ_code' - Invalid query: INSERT INTO `book_categories` (`categ_code`, `categ_name`) VALUES ('jhq', 'asdh')
ERROR - 2019-07-08 20:50:30 --> Severity: error --> Exception: syntax error, unexpected ',' /opt/lampp/htdocs/real/application/controllers/Library.php 45
ERROR - 2019-07-08 20:50:35 --> Severity: error --> Exception: syntax error, unexpected ',' /opt/lampp/htdocs/real/application/controllers/Library.php 45
ERROR - 2019-07-08 20:50:40 --> Severity: error --> Exception: syntax error, unexpected ',' /opt/lampp/htdocs/real/application/controllers/Library.php 45
ERROR - 2019-07-08 20:50:45 --> Severity: error --> Exception: syntax error, unexpected ',' /opt/lampp/htdocs/real/application/controllers/Library.php 45
ERROR - 2019-07-08 20:51:17 --> Query error: Duplicate entry 'test' for key 'categ_code' - Invalid query: INSERT INTO `book_categories` (`categ_code`, `categ_name`) VALUES ('test', 'tets')
