<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-23 18:15:03 --> Severity: error --> Exception: syntax error, unexpected '<' /opt/lampp/htdocs/real/application/views/library/pages/booklist.php 102
ERROR - 2019-07-23 18:15:10 --> Severity: error --> Exception: syntax error, unexpected '<' /opt/lampp/htdocs/real/application/views/library/pages/booklist.php 102
ERROR - 2019-07-23 18:17:00 --> Severity: error --> Exception: syntax error, unexpected '<' /opt/lampp/htdocs/real/application/views/library/pages/booklist.php 102
