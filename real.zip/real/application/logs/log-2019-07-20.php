<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-20 16:23:13 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::num_rows() /opt/lampp/htdocs/real/application/models/LibModel.php 65
ERROR - 2019-07-20 16:24:54 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::num_row() /opt/lampp/htdocs/real/application/models/LibModel.php 65
