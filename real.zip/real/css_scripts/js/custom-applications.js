$(function(){
  $("#submitapplicationreview").addClass("disabledstyle");
  $("#submiteducationupdate").prop("disabled",true);
  $("#submitappicationupdate").prop("disabled",true);
  $("#submitMainupdate").prop("disabled",true);
  $("#submitchurchexperience").prop("disabled",true);
  $("#submitFormExperience").prop("disabled",true);
});
